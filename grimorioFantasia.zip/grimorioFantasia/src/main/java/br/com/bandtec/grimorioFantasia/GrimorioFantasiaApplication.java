package br.com.bandtec.grimorioFantasia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrimorioFantasiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrimorioFantasiaApplication.class, args);
	}

}
