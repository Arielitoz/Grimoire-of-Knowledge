package br.com.bandtec.grimorioFantasia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrimorioFantasiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
